// routes/passwordRecovery.js
const express = require('express');
const router = express.Router();
const pool = require('../db');
const { verifyJWT, allowRoles } = require('../auth');
const crypto = require('crypto');

// Generate unique 20-char ID
async function generateUniqueId(table, column) {
    let unique = false;
    let id;

    while (!unique) {
        id = crypto.randomBytes(10).toString('hex').slice(0,20);
        const [rows] = await pool.query(
            `SELECT 1 FROM ${table} WHERE ${column} = ?`,
            [id]
        );

        if (rows.length === 0) unique = true;
    }

    return id;
}

//////////////////////////////////////////////////////
// 1️⃣ USER CREATES PASSWORD RECOVERY REQUEST
//////////////////////////////////////////////////////

router.post('/', verifyJWT, allowRoles('Victim','Volunteer','Dispatcher'), async (req,res)=>{

    const conn = await pool.getConnection();

    try{

        await conn.query("START TRANSACTION");

        const email = req.user.email;

        // check if user exists
        const [users] = await conn.query(
            "SELECT User_id FROM User WHERE Email = ?",
            [email]
        );

        if(users.length === 0){
            await conn.query("ROLLBACK");
            return res.status(404).json({message:"User not found"});
        }

        const recoveryId = await generateUniqueId("Password_Recovery","Recovery_id");

        // get all admins
        const [admins] = await conn.query(
            "SELECT User_id FROM Admin ORDER BY User_id"
        );

        if(admins.length === 0){
            await conn.query("ROLLBACK");
            return res.status(500).json({message:"No admins available"});
        }

        // round robin admin assignment
        const [lastAssigned] = await conn.query(
            `SELECT Admin_id 
             FROM Password_Recovery
             ORDER BY Request_time DESC
             LIMIT 1
             FOR UPDATE`
        );

        let nextAdminIndex = 0;

        if(lastAssigned.length > 0){

            const lastId = lastAssigned[0].Admin_id;

            const lastIndex = admins.findIndex(a => a.User_id === lastId);

            nextAdminIndex = (lastIndex + 1) % admins.length;
        }

        const assignedAdmin = admins[nextAdminIndex].User_id;

        // insert recovery request
        await conn.query(

            `INSERT INTO Password_Recovery
            (Recovery_id,User_email,Admin_id,Status)
            VALUES (?,?,?,'Pending')`,

            [recoveryId,email,assignedAdmin]

        );

        await conn.query("COMMIT");

        res.status(201).json({
            message:"Recovery request created",
            Recovery_id: recoveryId,
            assigned_admin: assignedAdmin
        });

    }
    catch(err){

        await conn.query("ROLLBACK");
        console.error(err);
        res.status(500).json({message:err.message});

    }
    finally{

        conn.release();

    }

});

//////////////////////////////////////////////////////
// 2️⃣ ADMIN VIEWS ALL REQUESTS
//////////////////////////////////////////////////////

router.get('/', verifyJWT, allowRoles('Admin'), async (req,res)=>{

    try{

        const [rows] = await pool.query(

            `SELECT *
            FROM Password_Recovery
            ORDER BY Request_time DESC`

        );

        res.json(rows);

    }
    catch(err){

        res.status(500).json({message:err.message});

    }

});

//////////////////////////////////////////////////////
// 3️⃣ ADMIN UPDATES REQUEST
//////////////////////////////////////////////////////

router.put('/:id', verifyJWT, allowRoles('Admin'), async (req,res)=>{

    const {status,note} = req.body;

    const recoveryId = req.params.id;

    const conn = await pool.getConnection();

    try{

        await conn.query("START TRANSACTION");

        const [rows] = await conn.query(

            `SELECT * FROM Password_Recovery
             WHERE Recovery_id = ?
             FOR UPDATE`,

            [recoveryId]

        );

        if(rows.length === 0){

            await conn.query("ROLLBACK");

            return res.status(404).json({
                message:"Request not found"
            });

        }

        if(rows[0].Status === "Processed"){

            await conn.query("ROLLBACK");

            return res.status(400).json({
                message:"Already processed"
            });

        }

        await conn.query(

            `UPDATE Password_Recovery
             SET Status=?, Note=?, Response_time=CURRENT_TIMESTAMP
             WHERE Recovery_id=?`,

            [status,note,recoveryId]

        );

        await conn.query("COMMIT");

        res.json({
            message:"Request updated"
        });

    }
    catch(err){

        await conn.query("ROLLBACK");

        res.status(500).json({
            message:err.message
        });

    }
    finally{

        conn.release();

    }

});

//////////////////////////////////////////////////////
// 4️⃣ ADMIN DELETE REQUEST
//////////////////////////////////////////////////////

router.delete('/:id', verifyJWT, allowRoles('Admin'), async (req,res)=>{

    const id = req.params.id;

    const conn = await pool.getConnection();

    try{

        await conn.query("START TRANSACTION");

        const [rows] = await conn.query(

            `SELECT * FROM Password_Recovery
             WHERE Recovery_id=?
             FOR UPDATE`,

            [id]

        );

        if(rows.length === 0){

            await conn.query("ROLLBACK");

            return res.status(404).json({
                message:"Request not found"
            });

        }

        await conn.query(

            `DELETE FROM Password_Recovery
             WHERE Recovery_id=?`,

            [id]

        );

        await conn.query("COMMIT");

        res.json({
            message:"Deleted successfully"
        });

    }
    catch(err){

        await conn.query("ROLLBACK");

        res.status(500).json({
            message:err.message
        });

    }
    finally{

        conn.release();

    }

});

//////////////////////////////////////////////////////
// 5️⃣ USER SEES THEIR REQUESTS
//////////////////////////////////////////////////////

router.get('/my-requests', verifyJWT, allowRoles('Victim','Volunteer','Dispatcher'), async (req,res)=>{

    try{

        const email = req.user.email;

        const [rows] = await pool.query(

            `SELECT *
            FROM Password_Recovery
            WHERE User_email = ?
            ORDER BY Request_time DESC`,

            [email]

        );

        res.json(rows);

    }
    catch(err){

        res.status(500).json({
            message:err.message
        });

    }

});

module.exports = router;