const express = require('express');
const router = express.Router();
const pool = require('../db'); // MySQL connection pool
const { verifyJWT, allowRoles } = require('../auth');

// Middleware: only volunteers can access
router.use(verifyJWT, allowRoles('Volunteer'));

// ======================
// GET CURRENT ASSIGNMENTS
// ======================
router.get('/assignments/current', async (req, res) => {
    try {
        const [rows] = await pool.query(
            `SELECT * 
             FROM volunteer_assigned_view
             WHERE Volunteer_ID = ? 
               AND Assignment_Status != 'Arrived'`, // Only ongoing/pending
            [req.user.id]
        );
        res.json(rows);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// ======================
// GET COMPLETED ASSIGNMENTS
// ======================
router.get('/assignments/history', async (req, res) => {
    try {
        const [rows] = await pool.query(
            `SELECT * 
             FROM volunteer_assigned_view
             WHERE Volunteer_ID = ? 
               AND Assignment_Status = 'Arrived'`, // Completed
            [req.user.id]
        );
        res.json(rows);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// ======================
// UPDATE ASSIGNMENT STATUS
// ======================
// ======================
// UPDATE ASSIGNMENT STATUS
// ======================
router.put('/assignment/:id', async (req, res) => {
    const { Status } = req.body;

    if (!Status || !['Arrived', 'Ongoing', 'Pending'].includes(Status)) {
        return res.status(400).json({ message: "Status is required and must be valid" });
    }

    try {
        const [result] = await pool.query(
            `UPDATE Volunteer v
             JOIN Volunteer_assignment va ON v.User_id = va.Volunteer_id
             JOIN Assignment a ON va.Assignment_id = a.Assignment_id
             SET v.Status = ?
             WHERE va.Assignment_id = ?
               AND v.User_id = ?
               AND a.Status != 'Arrived'`,
            [Status, req.params.id, req.user.id] // ✅ Fixed: was req.user.User_id
        );

        if (result.affectedRows === 0) {
            return res.status(400).json({ 
                message: "Cannot update status. Assignment is either completed or not assigned to you."
            });
        }

        res.json({ message: 'Your status has been updated successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// ======================
// UPDATE VOLUNTEER AVAILABILITY
// ======================
router.put('/availability', async (req, res) => {
    const { Availability } = req.body;
    if (!['Yes', 'No'].includes(Availability)) {
        return res.status(400).json({ message: "Availability must be 'Yes' or 'No'" });
    }

    try {
        const [rows] = await pool.query(
            `SELECT Status FROM Volunteer WHERE User_id = ?`,
            [req.user.id]
        );
        const currentStatus = rows[0].Status;

        // Prevent marking available if still assigned
        if (Availability === 'Yes' && currentStatus && currentStatus !== 'Arrived') {
            return res.status(400).json({ 
                message: `Cannot set availability to Yes. You are currently assigned (${currentStatus}).` 
            });
        }
        if (Availability === 'No' && currentStatus && currentStatus !== 'Arrived') {
            return res.status(400).json({ 
                message: `Cannot set availability to Yes. You are currently assigned (${currentStatus}).` 
            });
        }
        if (Availability === 'Yes') {
            await pool.query(
                `UPDATE Volunteer
                 SET Availability = 'Yes', Status = NULL
                 WHERE User_id = ?`,
                [req.user.id]
            );
        } else {
            await pool.query(
                `UPDATE Volunteer
                 SET Availability = 'No',Status = NULL
                 WHERE User_id = ?`,
                [req.user.id]
            );
        }

        res.json({ message: `Availability updated to ${Availability}` });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;