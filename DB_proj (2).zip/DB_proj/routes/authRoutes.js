const express = require('express');
const router = express.Router();
const pool = require('../db');
const jwt = require('jsonwebtoken');
const { hashPassword, comparePassword, JWT_SECRET } = require('../auth');
const crypto = require('crypto');

// Function to generate unique User ID
const generateUniqueUserId = async () => {
    let id;
    let exists = true;

    while (exists) {
        id = crypto.randomBytes(8).toString('hex'); // 16-char random string
        const [rows] = await pool.query('SELECT User_id FROM User WHERE User_id=?', [id]);
        exists = rows.length > 0;
    }

    return id;
};

// ---------------- REGISTER ----------------
router.post('/register', async (req, res) => {

    const { Name, Email, Phone_no, Address, Password, Date_of_Birth, Emergency_contact } = req.body;

    const conn = await pool.getConnection();

    try {

        // ==============================
        // INPUT VALIDATION
        // ==============================

        if (!Name || !Email || !Phone_no || !Address || !Password || !Date_of_Birth || !Emergency_contact) {
            return res.status(400).json({ message: "All fields are required" });
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(Email)) {
            return res.status(400).json({ message: "Invalid email format" });
        }

        const phoneRegex = /^\d{10,11}$/;
        if (!phoneRegex.test(Phone_no)) {
            return res.status(400).json({ message: "Phone number must be 10 or 11 digits" });
        }

        if (!phoneRegex.test(Emergency_contact)) {
            return res.status(400).json({ message: "Emergency contact must be 10 or 11 digits" });
        }

        const dob = new Date(Date_of_Birth);
        if (isNaN(dob.getTime())) {
            return res.status(400).json({ message: "Invalid Date_of_Birth format. Use YYYY-MM-DD" });
        }

        // ==============================
        // START TRANSACTION
        // ==============================

        await conn.query("START TRANSACTION");

        const user_id = await generateUniqueUserId();
        const hashedPassword = await hashPassword(Password);

        await conn.query(
            `INSERT INTO User (User_id, Name, Email, Phone_no, Address, Password, Date_of_Birth)
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [user_id, Name, Email, Phone_no, Address, hashedPassword, Date_of_Birth]
        );

        await conn.query(
            `INSERT INTO Victim (User_id, Emergency_contact) VALUES (?, ?)`,
            [user_id, Emergency_contact]
        );

        await conn.query("COMMIT");

        // ✏️ CHANGE 1: role → roles array in JWT and response
        const token = jwt.sign(
            { id: user_id, roles: ['Victim'] },
            JWT_SECRET,
            { expiresIn: "4h" }
        );

        res.status(201).json({
            message: "Victim registered successfully",
            user_id,
            roles: ['Victim'], // ✏️ CHANGE 2: role → roles array in response
            token
        });

    } catch (err) {

        await conn.query("ROLLBACK");
        console.error(err);
        res.status(500).json({ message: err.message });

    } finally {
        conn.release();
    }
});

// ---------------- LOGIN ----------------
router.post('/login', async (req, res) => {

    const { user_id, password } = req.body;

    try {

        // 1️⃣ Find user
        const [rows] = await pool.query(
            'SELECT * FROM User WHERE User_id=?',
            [user_id]
        );

        if (!rows.length)
            return res.status(404).json({ message: 'User not found' });

        const user = rows[0];

        // 2️⃣ Verify password
        const valid = await comparePassword(password, user.Password);
        if (!valid)
            return res.status(401).json({ message: 'Incorrect password' });

        // 3️⃣ Determine ALL roles from role tables
        // ✏️ CHANGE 3: replaced single role variable with roles array,
        //    all 4 queries now run and push into array instead of overwriting
        const roles = [];

        const [victim]     = await pool.query('SELECT User_id FROM Victim     WHERE User_id=?', [user_id]);
        const [volunteer]  = await pool.query('SELECT User_id FROM Volunteer  WHERE User_id=?', [user_id]);
        const [dispatcher] = await pool.query('SELECT User_id FROM Dispatcher WHERE User_id=?', [user_id]);
        const [admin]      = await pool.query('SELECT User_id FROM Admin      WHERE User_id=?', [user_id]);

        if (victim.length)     roles.push('Victim');
        if (volunteer.length)  roles.push('Volunteer');
        if (dispatcher.length) roles.push('Dispatcher');
        if (admin.length)      roles.push('Admin');

        if (!roles.length)
            return res.status(403).json({ message: 'Role not found for user' });

        // 4️⃣ Generate token
        // ✏️ CHANGE 4: role → roles array in JWT and response

        const token = jwt.sign(
            { id: user.User_id, email: user.Email, roles },
            JWT_SECRET,
            { expiresIn: '4h' }
        );
        res.json({ token, roles });

    } catch (err) {
        res.status(500).json({ message: err.message });
    }

});

module.exports = router;